# -*- coding: utf-8 -*-
from __future__ import unicode_literals

# xbmc imports
from xbmc import executebuiltin
from xbmcaddon import Addon
from xbmcgui import Dialog, DialogProgress

# codequick imports
from codequick import Route, run, Listitem, Script, Resolver
from codequick.utils import keyboard, urlparse, parse_qs
from codequick.script import Settings

# add-on imports
from .utils import isLoggedIn, check_addon, LOGGEDIN
from .constants import M3U_SRC, EPG_SRC, LANGUAGES, PROXY

# additional imports
import urlquick
import sys
import os
import socket
import time
import inputstreamhelper
from datetime import timedelta, date
from binascii import hexlify
from pickle import dumps


# Root path of plugin
@Route.register
@isLoggedIn
def root(plugin):
    for e in urlquick.get(PROXY+"/list/root", max_age=1800).json():
        yield Listitem.from_dict(**e)


# Shows Filter options
@Route.register
@isLoggedIn
def show_listby(plugin, by):
    for each in urlquick.get(PROXY+"/list/"+by, max_age=1800).json():
        yield Listitem.from_dict(**each)


# Shows channels by selected filter/category
@Route.register
@isLoggedIn
def show_category(plugin, category_id, id=False):
    is_helper = inputstreamhelper.Helper('mpd', drm="com.widevine.alpha")
    if is_helper.check_inputstream():
        fltr = "?id={0}&langs=".format(id) if id else "?langs="
        for x in LANGUAGES:
            if Settings.get_boolean(x):
                fltr += x + ","
        resp = urlquick.get(PROXY+"/list/" +
                            category_id + fltr[:-1], max_age=-1, timeout=60).json()
        for each in resp:
            catchup = each.get("isCatchupAvailable")
            channel_id = each.get("channelId")
            if catchup is not None:
                del each["isCatchupAvailable"]
            if channel_id is not None:
                del each["channelId"]
            litm = Listitem.from_dict(**each)
            if catchup:
                litm.context.container(show_epg, "Catchup", 0, channel_id)
            yield litm


# Shows EPG container from Context menu
@Route.register
@isLoggedIn
def show_epg(plugin, day, channel_id):
    resp = urlquick.get(
        PROXY+"/catchup/{0}/{1}".format(day, channel_id), max_age=-1).json()
    for each in resp:
        yield Listitem.from_dict(**each)
    if int(day) == 0:
        for i in range(-1, -7, -1):
            label = 'Yesterday' if i == - \
                1 else (date.today() + timedelta(days=i)).strftime('%A %d %B')
            yield Listitem.from_dict(**{
                "label": label,
                "callback": show_epg,
                "params": {
                    "day": i,
                    "channel_id": channel_id
                }
            })


# Play `route`
@Resolver.register
@isLoggedIn
def play(plugin, id):
    is_helper = inputstreamhelper.Helper('mpd', drm="com.widevine.alpha")
    if is_helper.check_inputstream():
        resp = urlquick.get(PROXY+"/playback/%d" % id, max_age=-1).json()[0]
        if resp.get("isCatchupAvailable") is not None:
            del resp["isCatchupAvailable"]
        if resp.get("channelId") is not None:
            del resp["channelId"]
        yield Listitem.from_dict(**resp)


# Login `route` to access from Settings
@Script.register
def login(plugin):
    pDialog = DialogProgress()
    web = Dialog().yesno('Login', 'Select Login Type',
                         nolabel='Keyboard', yeslabel='Web')
    if web:
        pDialog = DialogProgress()
        pDialog.create(
            'JioTV', 'Visit [B]http://%s:48996/web/login[/B] to login' % socket.gethostbyname(socket.gethostname()))
        for i in range(120):
            time.sleep(1)
            if urlquick.get(PROXY + "/login", max_age=-1, raise_for_status=False).status_code == 200 or pDialog.iscanceled():
                break
            pDialog.update(i)
    else:
        username = keyboard("Enter your Jio mobile number or email")
        password = keyboard("Enter your password", hidden=True)
        pDialog.create('JioTV', 'Login...')
        try:
            resp = urlquick.post(
                PROXY + "/login", data={"username": username, "password": password}, timeout=30, raise_for_status=False)
            if resp.status_code == 200:
                Script.notify('Login Success', '')
            else:
                try:
                    err = resp.json().get("errors", [{}])[0]
                    Script.notify(err.get("message", "Login Error"), err.get(
                        "details", {}).get("message", ["Something went wrong"])[0])
                except:
                    Script.notify('Login Failed', resp.text)
        except Exception as e:
            Script.notify("Login Error", repr(e).encode('utf-8'))
    pDialog.close()


# Logout `route` to access from Settings
@Script.register
def logout(plugin):
    LOGGEDIN = False
    urlquick.get(PROXY + "/logout", max_age=-1)


# M3u Generate `route`
@Script.register
@isLoggedIn
def m3ugen(plugin):
    channels = urlquick.get(PROXY + "/raw", max_age=-1).json()
    m3ustr = "#EXTM3U x-tvg-url=\"%s\"" % EPG_SRC
    for channel in channels:
        if not Settings.get_boolean(channel.get("language", True)) and Settings.get_boolean("uselang"):
            continue
        group = channel.get("language") + ";" + channel.get("genre")
        m3ustr += "\n#EXTINF:0 tvg-id=\"%d\" tvg-name=\"%s\" group-title=\"%s\" tvg-chno=\"%d\" tvg-logo=\"%s\",%s\nplugin://plugin.video.jiotv/resources/lib/main/play/?_pickle_=%s" % (
            channel.get("id"), channel.get("name"), group, channel.get("order"), channel.get("logo"), channel.get("name"), hexlify(dumps({"id": channel.get("id")})))
    with open(M3U_SRC, "w+") as f:
        f.write(m3ustr.replace(u'\xa0', ' ').encode('utf-8'))
    Script.notify("JioTV", "Playlist updated. Restart to apply.")


# PVR Setup `route` to access from Settings
@Script.register
def pvrsetup(plugin):
    if not os.path.exists(M3U_SRC):
        executebuiltin(
            "RunPlugin(plugin://plugin.video.jiotv/resources/lib/main/m3ugen/)")
    IDdoADDON = 'pvr.iptvsimple'
    if check_addon(IDdoADDON):
        Addon(IDdoADDON).getSetting(
            'm3uPathType') != '0' and Addon(IDdoADDON).setSetting(
            'm3uPathType', '0')
        Addon(IDdoADDON).getSetting(
            'm3uPath') != M3U_SRC and Addon(IDdoADDON).setSetting(
            'm3uPath', M3U_SRC)
        Addon(IDdoADDON).getSetting(
            'epgPathType') != '1' and Addon(IDdoADDON).setSetting(
            'epgPathType', '1')
        Addon(IDdoADDON).getSetting(
            'epgUrl') != EPG_SRC and Addon(IDdoADDON).setSetting(
            'epgUrl', EPG_SRC)


# Log upload `route`
@Script.register
@isLoggedIn
def logupload(plugin, crash=False):
    resp = urlquick.get(
        "{0}/log/upload?crash={1}".format(PROXY, "true" if crash else "false"), raise_for_status=False, max_age=-1)
    if resp.status_code == 200:
        msg = "%sLog uploaded to [B]%s[/B]" % (
            "Crash " if crash else "", resp.text)
    elif resp.status_code == 404:
        msg = "%sLog file missing" % "Crash " if crash else ""
    else:
        msg = "%sLog upload failed" % "Crash " if crash else ""
    Dialog().ok("Jiotv Service Log", msg)


# Cache cleanup
@Script.register
def cleanup(plugin):
    urlquick.cache_cleanup(-1)
    Script.notify("Cache Cleaned", "")
